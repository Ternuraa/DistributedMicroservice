module github.com/Ternuraa/DistributedMicroservice/services/booking_service

go 1.24.0

replace github.com/Ternuraa/DistributedMicroservice/listing_service => ../listing_service

require (
	github.com/Ternuraa/DistributedMicroservice/listing_service v0.0.0-00010101000000-000000000000
	github.com/google/uuid v1.6.0
	google.golang.org/grpc v1.79.3
)

require (
	github.com/rabbitmq/amqp091-go v1.11.0
	golang.org/x/net v0.48.0 // indirect
	golang.org/x/sys v0.39.0 // indirect
	golang.org/x/text v0.32.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20251202230838-ff82c1b0f217 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
	gopkg.in/yaml.v3 v3.0.1
)
