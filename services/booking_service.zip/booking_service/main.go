package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"time"

	proto "github.com/Ternuraa/DistributedMicroservice/listing_service/proto"
	"github.com/Ternuraa/DistributedMicroservice/services/booking_service/internal/config"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

func main() {
	// 1. Инициализируем конфиг через наш пакет
	cfg, err := config.Init("../../configs/booking_config.yaml")
	if err != nil {
		log.Fatalf("Ошибка загрузки конфига: %v", err)
	}

	// 2. gRPC соединение
	conn, err := grpc.Dial(cfg.ListingService.Address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("gRPC connection error: %v", err)
	}
	defer conn.Close()
	client := proto.NewListingServiceClient(conn)

	// 3. Роуты
	http.HandleFunc("/book", func(w http.ResponseWriter, r *http.Request) {
		listingID := r.URL.Query().Get("id")
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()

		resp, err := client.GetListingInfo(ctx, &proto.ListingRequest{Id: listingID})
		if err != nil {
			http.Error(w, "Listing not found", http.StatusNotFound)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"status": "success",
			"data":   resp,
		})
	})

	log.Printf("🚀 Booking Service (Clean Architecture) started on %s", cfg.Service.Port)
	log.Fatal(http.ListenAndServe(cfg.Service.Port, nil))
}
