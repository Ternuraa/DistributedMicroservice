package main

import (
	"context"
	"log"

	proto "github.com/Ternuraa/DistributedMicroservice/services/listing_service/proto"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type ListingServer struct {
	proto.UnimplementedListingServiceServer
}

// Имя функции оставляем GetListingDetails, так как его требует интерфейс .proto
func (s *ListingServer) GetListingDetails(ctx context.Context, req *proto.ListingRequest) (*proto.ListingResponse, error) {
	// 1. Проверяем, как называется поле ID в запросе. Скорее всего, просто Id.
	// Если VS Code подчеркнет req.Id, то поменяй на req.ListingId
	log.Printf("🚀 [Listing Service] Получен gRPC запрос на жильё с ID: %s", req.Id)

	if req.Id == "" {
		return nil, status.Errorf(codes.InvalidArgument, "ID не может быть пустым")
	}

	if req.Id == "404" {
		return nil, status.Errorf(codes.NotFound, "Жильё с таким ID не существует")
	}

	// 2. Возвращаем старые простые поля, которые точно есть в твоем сгенерированном файле
	return &proto.ListingResponse{
		Id:          req.Id,
		Price:       1500.50,
		IsAvailable: true,
	}, nil
}
