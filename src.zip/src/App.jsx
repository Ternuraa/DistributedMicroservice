import React, { useState } from 'react';
import { listings as initialListings } from './data';
import ListingCard from './components/ListingCard';
import BookingModal from './components/BookingModal';

export default function App() {
  const [listings, setListings] = useState(initialListings);
  const [selectedListing, setSelectedListing] = useState(null);

  const handleBookingSuccess = (listingId, start, end) => {
    // Обновляем состояние, добавляя забронированные дни локально
    setListings(prevListings => 
      prevListings.map(listing => {
        if (listing.id === listingId) {
          const newBookedDays = [...listing.bookedDays];
          for (let d = start; d <= end; d++) {
            if (!newBookedDays.includes(d)) newBookedDays.push(d);
          }
          return { ...listing, bookedDays: newBookedDays };
        }
        return listing;
      })
    );
    alert('Успешно забронировано!');
  };

  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 pb-20">
      {/* Шапка (Header) */}
      <header className="border-b px-8 py-4 flex items-center justify-between sticky top-0 bg-white z-40">
        <div className="text-2xl font-bold text-black tracking-tighter">Harbor</div>
        
        {/* Поиск */}
        <div className="hidden md:flex items-center border rounded-full p-2 px-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <span className="text-sm font-medium px-4 border-r">Куда отправиться?</span>
          <span className="text-sm font-medium px-4 border-r">Дата заезда</span>
          <span className="text-sm text-gray-500 px-4">Дата отъезда</span>
          <div className="bg-blue-500 text-white p-2 rounded-full ml-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
            </svg>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="text-sm font-medium hidden sm:block">Сдать жилье</button>
          <button className="border rounded-full p-2 flex items-center gap-2 px-3 hover:shadow-md">
            <span>☰</span>
            <div className="bg-gray-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">U</div>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-8 mt-10">
        
        {/* Секция: Где остановиться в Москве */}
        <section className="mb-16">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Где остановиться в Москве</h2>
            <div className="flex gap-2">
              <button className="p-2 border rounded-full hover:bg-gray-50">❮</button>
              <button className="p-2 border rounded-full hover:bg-gray-50">❯</button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Рендерим карточки. Для примера дублируем массив, чтобы заполнить ряд */}
            {[...listings, ...listings].map((listing, index) => (
              <ListingCard 
                key={`${listing.id}-${index}`} 
                listing={listing} 
                onClick={(item) => setSelectedListing(item)} 
              />
            ))}
          </div>
        </section>

        {/* Секция: Баннер с призывом (Имитация из макета) */}
        <section className="relative rounded-2xl overflow-hidden mb-16 bg-gray-900 text-white flex items-center">
           <div className="p-12 relative z-10 w-full md:w-1/2">
             <h2 className="text-4xl font-bold mb-4">Зарабатывайте,<br/>открывая двери<br/>своего дома</h2>
             <p className="mb-8">Потенциальный доход:<br/><span className="text-2xl font-semibold text-green-400">до 85 000 ₽ / месяц</span></p>
             <button className="bg-white text-black px-6 py-3 rounded-lg font-semibold hover:bg-gray-100">Стать хозяином</button>
           </div>
           {/* Декоративный градиент/картинка для баннера */}
           <div className="absolute inset-0 right-0 left-1/2 bg-gradient-to-l from-transparent to-gray-900 hidden md:block z-0"></div>
           <img src="https://images.unsplash.com/photo-1554995207-c18c203602cb" alt="Banner" className="absolute inset-0 w-full h-full object-cover opacity-50 md:opacity-100 md:left-1/3" />
        </section>

      </main>

      {/* Модальное окно бронирования */}
      {selectedListing && (
        <BookingModal 
          listing={selectedListing} 
          onClose={() => setSelectedListing(null)} 
          onBookingSuccess={handleBookingSuccess}
        />
      )}
    </div>
  );
}