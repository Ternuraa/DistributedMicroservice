export const listings = [
  {
    id: "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
    title: "Квартира у Анны",
    location: "Светлая квартира • Центральный район",
    rating: "4.89",
    reviews: "102",
    pricePerNight: 7000,
    priceTotal: "Всего 14 000 ₽ за 2 ночи",
    image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=600&q=80",
    bookedDays: [5, 6, 7, 12, 13, 14, 20],
    noCommission: true
  },
  {
    id: "b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a22",
    title: "Лофт с панорамными окнами",
    location: "Стильный лофт • Район у реки",
    rating: "4.95",
    reviews: "84",
    pricePerNight: 8500,
    priceTotal: "Всего 17 000 ₽ за 2 ночи",
    image: "https://images.unsplash.com/photo-1502672260266-1c1e52409818?auto=format&fit=crop&w=600&q=80",
    bookedDays: [1, 2, 3, 15, 16, 17, 18, 28, 29, 30],
    noCommission: true
  }
];