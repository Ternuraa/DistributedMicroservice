import React from 'react';

export default function ListingCard({ listing, onClick }) {
  return (
    <div 
      className="flex flex-col cursor-pointer group" 
      onClick={() => onClick(listing)}
    >
      <div className="relative aspect-[4/3] overflow-hidden rounded-xl mb-3">
        <img 
          src={listing.image} 
          alt={listing.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <button className="absolute top-3 right-3 text-white hover:text-red-500 transition-colors">
          {/* Иконка сердечка */}
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z" />
          </svg>
        </button>
      </div>

      <div className="flex justify-between items-start mb-1">
        <h3 className="font-semibold text-gray-900 truncate">{listing.title}</h3>
        <div className="flex items-center text-sm">
          <span className="text-black">★</span>
          <span className="ml-1 font-medium">{listing.rating}</span>
          <span className="text-gray-500 ml-1">({listing.reviews})</span>
        </div>
      </div>

      <p className="text-gray-500 text-sm truncate">{listing.location}</p>
      
      <div className="mt-1 flex items-baseline gap-1">
        <span className="font-semibold text-gray-900">{listing.pricePerNight} ₽</span>
        <span className="text-gray-500 text-sm">/ ночь</span>
      </div>
      
      <p className="text-gray-500 text-sm mt-1">{listing.priceTotal}</p>

      {listing.noCommission && (
        <div className="mt-2">
          <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-md font-medium">
            Без комиссии
          </span>
        </div>
      )}
    </div>
  );
}