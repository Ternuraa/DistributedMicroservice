import React, { useState, useEffect } from 'react';

export default function BookingModal({ listing, onClose, onBookingSuccess }) {
  const [startDay, setStartDay] = useState(null);
  const [endDay, setEndDay] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Сброс состояния при смене квартиры
  useEffect(() => {
    setStartDay(null);
    setEndDay(null);
    setError('');
  }, [listing]);

  if (!listing) return null;

  const handleDayClick = (day) => {
    if (listing.bookedDays.includes(day)) return;

    if (!startDay || (startDay && endDay)) {
      setStartDay(day);
      setEndDay(null);
    } else {
      if (day < startDay) {
        setEndDay(startDay);
        setStartDay(day);
      } else {
        setEndDay(day);
      }
    }
  };

  // Проверка пересечений с занятыми датами
  const hasOverlap = () => {
    if (startDay && endDay) {
      for (let d = startDay; d <= endDay; d++) {
        if (listing.bookedDays.includes(d)) return true;
      }
    }
    return false;
  };

  useEffect(() => {
    if (hasOverlap()) {
      setError('В выбранном диапазоне есть занятые даты!');
      setEndDay(null);
    } else {
      setError('');
    }
  }, [startDay, endDay]);

  const executeBooking = async () => {
    if (!startDay || !endDay) return;
    setLoading(true);

    try {
      // Имитация API запроса (замените на ваш реальный fetch)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Вызываем коллбек успешного бронирования (чтобы обновить данные)
      onBookingSuccess(listing.id, startDay, endDay);
      onClose();
    } catch (err) {
      setError("Ошибка сервера при бронировании");
    } finally {
      setLoading(false);
    }
  };

  const renderCalendar = () => {
    const days = [];
    for (let day = 1; day <= 30; day++) {
      const isBooked = listing.bookedDays.includes(day);
      let isSelected = startDay === day || endDay === day;
      let isBetween = startDay && endDay && day > startDay && day < endDay;

      let classes = "p-2 rounded-lg text-center transition-all duration-200 select-none ";

      if (isBooked) {
        classes += "bg-gray-100 text-gray-400 line-through cursor-not-allowed";
      } else if (isSelected || isBetween) {
        classes += "bg-black text-white font-bold cursor-pointer";
      } else {
        classes += "bg-gray-50 text-gray-700 hover:bg-gray-200 cursor-pointer border";
      }

      days.push(
        <div key={day} className={classes} onClick={() => handleDayClick(day)}>
          {day}
        </div>
      );
    }
    return days;
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col md:flex-row relative">
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-100 z-10"
        >
          ✕
        </button>

        <div className="md:w-1/2 h-64 md:h-auto">
          <img src={listing.image} alt="Апартаменты" className="w-full h-full object-cover" />
        </div>

        <div className="md:w-1/2 p-8 flex flex-col overflow-y-auto">
          <h2 className="text-2xl font-bold mb-2">{listing.title}</h2>
          <p className="text-xl font-semibold mb-6">{listing.pricePerNight} ₽ <span className="text-sm text-gray-500 font-normal">/ ночь</span></p>

          <div className="mb-6">
            <span className="font-semibold block mb-3">Выберите даты (Июнь 2026):</span>
            <div className="grid grid-cols-7 gap-2 text-sm">
              {renderCalendar()}
            </div>
          </div>

          <div className="mt-auto">
            {error && <p className="text-red-500 text-sm mb-3">{error}</p>}
            
            <p className="text-sm text-gray-600 mb-4 h-5">
              {!startDay && "Выберите дату заезда"}
              {startDay && !endDay && `Заезд: ${startDay} июня. Выберите дату выезда`}
              {startDay && endDay && `Выбрано: ${startDay} - ${endDay} июня`}
            </p>

            <button 
              onClick={executeBooking}
              disabled={!startDay || !endDay || loading}
              className="w-full bg-black hover:bg-gray-800 text-white font-bold py-3 px-4 rounded-lg disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? "Бронирование..." : "Забронировать"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}